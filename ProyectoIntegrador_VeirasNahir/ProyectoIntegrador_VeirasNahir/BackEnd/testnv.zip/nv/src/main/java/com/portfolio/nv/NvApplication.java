package com.portfolio.nv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NvApplication {

	public static void main(String[] args) {
		SpringApplication.run(NvApplication.class, args);
	}

}
